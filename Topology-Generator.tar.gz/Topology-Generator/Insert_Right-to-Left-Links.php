#!/usr/bin/php
<?php
	$db_host ="localhost:3036";
	$db_user = "root";
	$db_password = "123456";
	$connection = mysql_connect($db_host,$db_user, $db_password);
	
////Connection to MariaDB//

	$result = mysql_select_db("Domain_1",$connection);
	if(!$result)
	{
		die("Failed to Select Domain_1:".mysql_error());
	}
	else
	 {
	   echo "Domain_1 selection was successful\n"; 
	   
		}
/////Database selection//


for ($Row=1;$Row<=30;$Row++ )
  { 
    $RIFA=1;
    $LID=1;
    $LIFA=2;
    $a=4;
    $x=1;
    for ($Clm=2;$Clm<=30;$Clm++ )
    {
	$LID=$Clm-1;
	$RIFA=$LIFA-1;


$sql = "INSERT INTO Traffic_Eng".
	"(RouterID,Linktype,LinkID,LocalIFAdr,RemIFAdr,TEmetric,MaxBW,MaxRsvBW,UnRsvBW_P_0,UnRsvBW_P_1,UnRsvBW_P_2,UnRsvBW_P_3,UnRsvBW_P_4,UnRsvBW_P_5,UnRsvBW_P_6,UnRsvBW_P_7, AdminGrp) ".
	"VALUES".
   

      "(\"1.1.$Row.$Clm\",$Clm,\" 1.1.$Row.$LID\",\"10.$Row.$x.$LIFA\",\"10.$Row.$x.$RIFA\", 2,'100', '100','100','100','100','100','100','100','100','100',$Row)";
	  $LIFA=($LIFA+$a);
	  $sqlx= mysql_query($sql,$connection);
	  	if ($LIFA>=255) {
          $LIFA=2; $x=2;
           }
	}
  }
	  
	  
	  if(!$sqlx)
	{
		die("Failed to Insert:".mysql_error());
	}
	else
	 {
	   echo "Insert was successful\n"; 
	   
		}
////INSERT INTO TABLE////

	

mysql_close($connection);
?>

