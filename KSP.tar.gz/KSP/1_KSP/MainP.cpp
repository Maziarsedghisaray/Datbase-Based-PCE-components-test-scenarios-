/************************************************************************/
/* $Id: MainP.cpp 65 2010-09-08 06:48:36Z yan.qi.asu $                                                                 */
/************************************************************************/
#include <iostream>
#include <vector>
#include <unistd.h>
#include<thread>
#include<iomanip>
#include<utility>
#include <cstdlib>
#include<tuple>
#include<functional>
#include <string>
#include<fstream>
#include <sstream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <map>
#include <unordered_map>
#include <limits>
#include <set>
#include <map>
#include <queue>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>
#include "GraphElements.h"
#include "Graph.h"
#include "DijkstraShortestPathAlg.h"
#include "YenTopKShortestPathsAlg.h"

using namespace std;

map <string,int> NODES;
map <string,int>::iterator it;
int NodeNum;

struct Topology {
	string RID;
	int    SrcNID;
	string LID;
	int    DestNID;
	string LocIntF;
	string RemIntF;
	int    TEmetric;
	int    ResvBW;
		
};

vector<Topology> Data;


void prepareData()
{
	
	//////// indexing Nodes /////////
	ifstream f("data/Nodes");
	if(!f.is_open())
	{
		cout<< "Error, file is not open\n";
	}

   else
  {
	string temp;
 	while ( getline (f,temp) )
    {
      NODES [temp];
    }
  }
   f.close();
	
	int x=0;
	for (it = NODES.begin(); it != NODES.end(); it++)
	{
		 it->second = x; 
		 x++;
		
	}

	 NodeNum = NODES.size();

  //////// inserting Topology data ////////
	ifstream P("data/Links");
  if(!P.is_open())
  {
  cout<< "Error, file is not open\n";
  }
  else
  {
	  int entry;
	  P >> entry;
  for (int i = 0; i < entry; i++)
  {
	Data.push_back(Topology());
	
	string t1;
	P >> t1;
	Data[i].RID = t1;
	map <string,int>::const_iterator got = NODES.find (t1);
	Data[i].SrcNID = got->second; 
	
	string t2;
	P >> t2;
	Data[i].LID = t2;
	map <string,int>::const_iterator got2 = NODES.find (t2);
	Data[i].DestNID = got2->second;
	  
	string t3;
	P >> t3;
	Data[i].LocIntF = t3;
	  
	string t4;
	P >> t4;
	Data[i].RemIntF = t4;
	
	int t5;
	P >> t5;
	Data[i].TEmetric = t5;
	
	int t6;
	P >> t6;
	Data[i].ResvBW = t6;

  }

  }	
   P.close();	
	
  //////// Preparing File for computation //////
	ofstream b("data/danYen");

	b << NodeNum << endl;
	
	for(int j=0;j< Data.size();j++)
	{
		b  << Data[j].SrcNID   << "  " << Data[j].DestNID << "   " << Data[j].TEmetric<< endl;
		
	}


b.close();
	
}

void ConvertData()
{ 
	//////////////////////////////////////////////  converting results //////////////////////////////////
	ofstream m("Final_Result/Final_Result.txt");
	ifstream Q("data/RESULTS-ksp");
if(!Q.is_open())
{
cout<< "Error, file is not open-RKSP\n";
}
else
{
	string Line;  int j=0;
 	while ( getline (Q, Line, '\n' ))
    {
			vector <int> SS;   		
		    std::istringstream is(Line);
      		
			int number;
     	    for (int f = 0; is >> number; ++f)
			{

               SS.push_back(number);
			}
	
	
	string Src;
	string Dest;
	for (auto itr = NODES.begin(); itr != NODES.end(); itr++)
	{
		if (SS[0] == itr->second) 
		{
			Src = itr->first;
			
		}
		
		if (SS[SS.size()-1] == itr->second) 
		{
			 Dest = itr->first;
			
		}	
	}
		
	      j++;
		  if (j >= 4)
		   {
			   j=1;
	       }
		  else
		  {
			 ;
		  }
	   for(int y=0; y < SS.size()-1;y++)
	   {
		   int index;
		   
			for (int h = 0; h < Data.size(); ++h)
			{
				if(SS[y] == Data[h].SrcNID && SS[y+1] == Data[h].DestNID)
				{
					index = h;
					break;
					
				}
				
			}
		   
		   

		   m << j << "   " << Src << "-" << Dest << "   " << Data[index].RID << "   " << Data[index].LID << "   " << Data[index].LocIntF << "   " << Data[index].RemIntF << "   " << Data[index].TEmetric << "   " << Data[index].ResvBW << endl; 
		   


	   }
	
			SS.clear();
	 
		 
	}


}
	m.close();
	
	
	
}



void testDijkstraGraph()
{
	Graph* my_graph_pt = new Graph("data/danYen");
	DijkstraShortestPathAlg shortest_path_alg(my_graph_pt);
	BasePath* result =
		shortest_path_alg.get_shortest_path(
			my_graph_pt->get_vertex(1), my_graph_pt->get_vertex(4));
	result->PrintOut(cout);
}

void testYenAlg()
{
	Graph my_graph("data/danYen");
	
  for (int i=0; i<NodeNum;i++)
   {
	for (int j= 0; j <NodeNum; j++ )
	{
   
	if(i != j)
	{
		YenTopKShortestPathsAlg yenAlg(my_graph, my_graph.get_vertex(i),
		my_graph.get_vertex(j));
	
	
	 int k=0;
	 while(k<3)
	 {
		++k;
		yenAlg.next()->PrintOut(cout);
	 }	

		
	}
  else
  {
	;  
  }
	 }
	}
}

int main(...)
{

	//testDijkstraGraph();
	prepareData();
	testYenAlg();
	ConvertData();
	
	
}
