#!/usr/bin/php
<?php
	$db_host ="localhost:3036";
	$db_user = "root";
	$db_password = "123456";
	$connection = mysql_connect($db_host, $db_user, $db_password);
	
	/////////////Connection to MariaDB///////////////////////////////////////////////

	$result = mysql_select_db("D1_DB",$connection);
	
//////////////////////////////Database selection///////////////////////////////////////////////
	
	
		

	$sql = "select RouterID,LinkID,LocalIFAdr,RemIFAdr,TEmetric,MaxRsvBW from TED2 order by RouterID;"; 
	$return = mysql_query($sql,$connection);
	if(!$return)
	{
		die("Failed to Select:".mysql_error());
	}
	else
	 {
	   echo "Select was successful\n"; 
	   $handle = fopen('/root/TOPOLOGY_GENERATOR/Links','w+') or die('couldnt open the file for writing');
	   while ($row = mysql_fetch_array($return,MYSQL_ASSOC))
		{
		 fputs($handle, join('      ', $row)."\n");
		}
	  
                echo "Fetched data successfully\n";

		fclose($handle);
	 }
	
   
      

	mysql_close($connection);


?>

