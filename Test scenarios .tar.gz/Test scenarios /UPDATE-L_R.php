#!/usr/bin/php
<?php
        $db_host ="localhost:3036";
        $db_user = "root";
        $db_password = "123456";
        $connection = mysql_connect($db_host,$db_user, $db_password);

////Connection to MariaDB//

        $result = mysql_select_db("Domain_1",$connection);
        if(!$result)
        {
                die("Failed to Select Domain_1:".mysql_error());
        }
        else
         {
           echo "Domain_1 selection was successful\n";

                }
/////Database selection//

$sqlPro = "SET profiling = 1";
        $return_Pro = mysql_query($sqlPro,$connection);
        $sql100 = "set profiling_history_size=100";
        mysql_query($sql100,$connection);

//////Profiling=1///
for ($Row=1;$Row<=10;$Row++ )
  {


    $LIFA=1;
    $a=4;
    $x=1;
    for ($Clm=1;$Clm<=10;$Clm++ )
    {

$sql = "UPDATE Traffic_Eng ".
        "SET MaxRsvBW = '50 Mbps'".
        " WHERE".
      " LocalIfAdr= '10.$Row.$x.$LIFA'";

          
          $sqlx= mysql_query($sql,$connection);
		  $LIFA=($LIFA+$a);
          if ($LIFA>=255) {
		          $LIFA=1; $x=2;
           }




     }


         $sqlSH = "SHOW PROFILES";
         $return_SH = mysql_query($sqlSH,$connection);


         if(!$return_SH)
        {
                die("Failed to SHOW Profile:".mysql_error());
        }
	else
	 {
	    
	   $handle = fopen('Update_Time','a+') or die('couldnt open the file for writing');
	   while ($row = mysql_fetch_array($return_SH,MYSQL_ASSOC))
		{
		 fputs($handle, join('  |', $row)."\n");
		}
	  
             

		fclose($handle);
	 }

    }

  if(!$sqlx)
        {
                die("Failed to UPDATE:".mysql_error());
        }
        else
         {
           echo "UPDATE was successful\n"; }

                   mysql_close($connection);





?>
