#!/usr/bin/php
<?php
	$db_host ="localhost:3036";
	$db_user = "root";
	$db_password = "";
	$connection = mysql_connect($db_host,$db_user, $db_password);
	
////Connection to MariaDB//

	$resultA = mysql_select_db("Domain_1",$connection);
	if(!$resultA)
	{
		die("Failed to Select Domain_1:".mysql_error());
	}
	else
	 {
	   echo "Domain_1 selection was successful\n"; 
	   
		}
	
/////////////////////////////////////////

$fhandle=fopen("Final_Result.txt", "r");
fgets($fhandle);

while($line=fgets($fhandle)){

	 $words=explode("   ",$line);
         $Prio = $words[0];
	 $Path = $words[1];
         $RouterID = $words[2];
	 $LinkID = $words[3];
	 $LocalIFAdr = $words[4];
	 $RemIFAdr = $words[5];
	 $TEmetric = $words[6];
	 $MaxRsvBW = $words[7];
	
	$sql="INSERT INTO LSP_Candidate (Prio, Path, RouterID,LinkID,LocalIFAdr,RemIFAdr,TEmetric,MaxRsvBW) VALUES (\"$Prio\", \"$Path\", \"$RouterID\", \"$LinkID\", \"$LocalIFAdr\",\"$RemIFAdr\",$TEmetric,$MaxRsvBW)";  

      $sqlx= mysql_query($sql,$connection);
      //sleep(1);

}
	
if (!$sqlx) {
    die("Could not load. " . mysql_error());  
	 
}
else 
{ echo "Insert was sucessful";}
	


mysql_close($connection);
?>

