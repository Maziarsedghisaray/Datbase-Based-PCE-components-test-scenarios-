#!/usr/bin/php
<?php
        $db_host ="localhost:3036";
        $db_user = "root";
        $db_password = "123456";
        $connection = mysql_connect($db_host,$db_user, $db_password);

////Connection to MariaDB//

        $result = mysql_select_db("Domain_1",$connection);
        if(!$result)
        {
                die("Failed to Select Domain_1:".mysql_error());
        }
        else
         {
           echo "Domain_1 selection was successful\n";

                }

/////Database selection//

$sqlPro = "SET profiling = 1";
        $return_Pro = mysql_query($sqlPro,$connection);
        $sql100 = "set profiling_history_size=100";
        mysql_query($sql100,$connection);

//////Profiling=1///

/////////////////////////////////////////

for ($Row=1;$Row<=10;$Row++ )
  {
    $RIFA=1;
    $LID=1;
    $LIFA=1;
    $a=4;
    $x=1;
    for ($Clm=1;$Clm<=9;$Clm++ )
    {
        $LID=$Clm+1;
        $RIFA=$LIFA+1;


$sql = "UPDATE Traffic_Eng SET MaxRsvBW =100 WHERE LocalIfAdr= '10.$Row.$x.$LIFA'";

          $LIFA=($LIFA+$a);

          $sqlx= mysql_query($sql,$connection);
                if ($LIFA>=255) {
          $LIFA=1; $x=2;
           }
        }
  }


          if(!$sqlx)
        {
                die("Failed to Insert:".mysql_error());
        }
        else
         {
           echo "Insert was successful\n";
                }
////INSERT INTO TABLE////
        $sqlSH = "SHOW PROFILES";
         $return_SH = mysql_query($sqlSH,$connection);


         if(!$return_SH)
        {
                die("Failed to SHOW Profile:".mysql_error());
        }
        else
         {

           $handle = fopen('T2_normal_Insert','a+') or die('couldnt open the file for writing');
           while ($row = mysql_fetch_array($return_SH,MYSQL_ASSOC))
                {
                 fputs($handle, join('   ', $row)."\n");
                }



                fclose($handle);
         }


mysql_close($connection);
?>


