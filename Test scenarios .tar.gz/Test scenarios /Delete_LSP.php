#!/usr/bin/php
<?php
	$db_host ="localhost:3036";
	$db_user = "root";
	$db_password = "";
	$connection = mysql_connect($db_host,$db_user, $db_password);
	
////Connection to MariaDB//

	$resultA = mysql_select_db("Domain_1",$connection);
	if(!$resultA)
	{
		die("Failed to Select Domain_1:".mysql_error());
	}
	else
	 {
	   echo "Domain_1 selection was successful\n"; 
	   
		}

/////Database selection//

$sqlPro = "SET profiling = 1";
        $return_Pro = mysql_query($sqlPro,$connection);
        $sql100 = "set profiling_history_size=100";
        mysql_query($sql100,$connection);

//////Profiling=1///
	
/////////////////////////////////////////

$fhandle=fopen("FILE_LSP_ESTAB","r");
fgets($fhandle);

while($line=fgets($fhandle)){

	 $words=explode("   ",$line);
         $Path = $words[0];
         $RouterID = $words[1];
	 $LinkID = $words[2];
	 $LocalIFAdr = $words[3];
	 $RemIFAdr = $words[4];
	 $TEmetric = $words[5];
	 $MaxRsvBW = $words[6];
	
	$sql="Delete FROM Estab_LSP WHERE Path = \"$Path\" AND RouterID = \"$RouterID\" AND LinkID = \"$LinkID\" AND LocalIFAdr = \"$LocalIFAdr\" AND RemIFAdr= \"$RemIFAdr\" ";  

      $sqlx= mysql_query($sql,$connection);
      //sleep(1);

}
	
if (!$sqlx) {
    die("Could not load. " . mysql_error());  
	 
}
else 
{ echo "delete was sucessful";}



        $sqlSH = "SHOW PROFILES";
         $return_SH = mysql_query($sqlSH,$connection);


         if(!$return_SH)
        {
                die("Failed to SHOW Profile:".mysql_error());
        }
	else
	 {
	    
	   $handle = fopen('Del_Time','a+') or die('couldnt open the file for writing');
	   while ($row = mysql_fetch_array($return_SH,MYSQL_ASSOC))
		{
		 fputs($handle, join('   ', $row)."\n");
		}
	  
             

		fclose($handle);
	 }

     

	


mysql_close($connection);
?>

