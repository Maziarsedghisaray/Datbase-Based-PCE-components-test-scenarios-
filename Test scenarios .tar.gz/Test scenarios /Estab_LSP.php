#!/usr/bin/php
<?php
	$db_host ="localhost:3036";
	$db_user = "root";
	$db_password = "123456";
	$connection = mysql_connect($db_host,$db_user, $db_password);
	
////Connection to MariaDB//

	$resultA = mysql_select_db("D1_DB",$connection);
	if(!$resultA)
	{
		die("Failed to Select Domain_1:".mysql_error());
	}
	else
	 {
	   echo "Domain_1 selection was successful\n"; 
	   
		}

/////Database selection//

$sqlPro = "SET profiling = 1";
        $return_Pro = mysql_query($sqlPro,$connection);
        $sql100 = "set profiling_history_size=100";
        mysql_query($sql100,$connection);

//////Profiling=1///
	
/////////////////////////////////////////

$fhandle=fopen("Establish_LSP.txt", "r");
fgets($fhandle);

while($line=fgets($fhandle)){

	 $words=explode("   ",$line);
         $Path = $words[0];
         $RouterID = $words[1];
	 $LinkID = $words[2];
	 $LocalIFAdr = $words[3];
	 $RemIFAdr = $words[4];
	 $TEmetric = $words[5];
	 $MaxRsvBW = $words[6];
	
	$sql="INSERT INTO Estab_LSP (Path, RouterID,LinkID,LocalIFAdr,RemIFAdr,TEmetric,MaxRsvBW) VALUES (\"$Path\", \"$RouterID\", \"$LinkID\", \"$LocalIFAdr\",\"$RemIFAdr\",$TEmetric,10)";  

      $sqlx= mysql_query($sql,$connection);
      //sleep(1);

}
	
if (!$sqlx) {
    die("Could not load. " . mysql_error());  
	 
}
else 
{ echo "Insert was sucessful";}



        $sqlSH = "SHOW PROFILES";
         $return_SH = mysql_query($sqlSH,$connection);


         if(!$return_SH)
        {
                die("Failed to SHOW Profile:".mysql_error());
        }
	else
	 {
	    
	   $handle = fopen('/root/Desktop/TOPOLOGY_GENERATOR/Estab_LSP/hhh.txt','a+') or die('couldnt open the file for writing');
	   while ($row = mysql_fetch_array($return_SH,MYSQL_ASSOC))
		{
		 fputs($handle, join('   ', $row)."\n");
		}
	  
             

		fclose($handle);
	 }

     

	


mysql_close($connection);
?>

